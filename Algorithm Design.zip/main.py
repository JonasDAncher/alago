from asyncore import read
import numpy as np
import collections


def remove_prefix(text, prefix):
    if text.startswith(prefix):
        return text[len(prefix):]
    return text

def parse_ranking(text):
    rankings = text.split(' ')
    rankings = list(map(int, list(filter(None, rankings)))) #None is equal to the empty char ''
    rankings = list(map(lambda x: x-1, rankings))
    return rankings


def parse_input(lines):
    people = []
    rankings = []

    for line in lines:
        if not (line.startswith('#') | line.startswith('n=') | line.startswith('\n')):
            number_string = line[0]
            index = 1

            while number_string.isdigit():
                number_string += line[index]
                index += 1

            if not number_string.endswith(':'):
                name = remove_prefix(line, number_string)
                people.append(name[:-1])
            else:
                ranking = remove_prefix(line, number_string)
                if ranking[-1] == '\n':
                    ranking = ranking[:-1]
                rankings.append(parse_ranking(ranking))
    
    return people, rankings


input_file_name = input()

input_file = open(input_file_name, "r")

lines = input_file.readlines()

people, rankings = parse_input(lines)
rankings = np.array(rankings).astype(int)

n = int(len(people) / 2)

# next[] is the amount of women each man has proposed to
next = np.zeros(2 * n).astype(int)

# If a woman w is engaged to man m then current[w] = m.
current = np.empty(2 * n).astype(int)

reverse_ranking = np.empty((2 * n, 2 * n)).astype(int)

# free_list consists of all men, not currently engaged
free_list = collections.deque()


def mainLoop():
    while free_list:
        cur_guy = free_list.pop()
        wanted_woman = rankings[cur_guy, next[cur_guy]]
        if not current[wanted_woman]:
            current[wanted_woman] = cur_guy
        elif reverse_ranking[wanted_woman, cur_guy] < reverse_ranking[wanted_woman, current[wanted_woman]]:
            free_list.append(current[wanted_woman])
            current[wanted_woman] = cur_guy
        else:
            free_list.append(cur_guy)
        next[cur_guy] += 1


def fillFreeList():
    for i in range(0, 2 * n, 2):
        free_list.append(i)


# Hop through only women in the rankings array
def constructReverseRanking():
    for i in range(1, 2 * n, 2):
        for j in range(n):
            reverse_ranking[i, rankings[i, j]] = j

def makeRankingString():
    ret_val = ""
    for i in range(1, 2*n, 2):
        ret_val += people[current[i]] + " -- " +  people[i] + "\n"
    return ret_val

constructReverseRanking()
fillFreeList()
mainLoop()

print(makeRankingString())